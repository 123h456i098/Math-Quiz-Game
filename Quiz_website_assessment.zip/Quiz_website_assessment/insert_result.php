<?php
$dbc = mysqli_connect("localhost", "thompsal", '$2y$10$YuhE1dWv3xY4J5aOdllJF.Arr8WH8Z8dYAoInl6ZtmGOrIHuHBhde', "thompsal_Quiz_questions_and_answers");
mysqli_set_charset($dbc, "utf8");

$score = $_COOKIE['score'];
$name = $_COOKIE['name'];
echo "$score, $name";
	
$quizid = $_GET['id'];
	
// 	Add information into database
$sql = "INSERT INTO `Results` (`ResultID`, `QuizID`, `Name`, `Score`) VALUES (NULL, '$quizid', '$name', '$score')"; 
	
mysqli_query($dbc, $sql);
?>

<script>
	window.open("https://priscilla2.onslownet.school.nz/users/thompsal/Quiz_website_assessment/scoreboard.php","_self")
</script>
