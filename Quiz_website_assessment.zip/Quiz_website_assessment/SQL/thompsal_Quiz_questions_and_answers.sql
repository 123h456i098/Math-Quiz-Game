-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 12, 2021 at 12:53 PM
-- Server version: 5.6.33-0ubuntu0.14.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thompsal_Quiz_questions_and_answers`
--

-- --------------------------------------------------------

--
-- Table structure for table `Answers`
--

CREATE TABLE `Answers` (
  `AnswerID` mediumint(8) UNSIGNED NOT NULL,
  `QuestionID` tinyint(3) UNSIGNED NOT NULL,
  `Answer` varchar(75) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Correct` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Stores all Answers, defining whether they are right or wrong';

--
-- Dumping data for table `Answers`
--

INSERT INTO `Answers` (`AnswerID`, `QuestionID`, `Answer`, `Correct`) VALUES
(1, 1, 'Ngāti Toa Rangatira', 1),
(2, 1, 'Ngati Toa Rangatira', 1),
(3, 1, 'Ngāti Toarangatira', 1),
(4, 1, 'Ngati Toarangatira', 1),
(5, 1, 'Ngā Toa Rangatahi', 0),
(6, 1, 'Ngāti Toa Ruatahi', 0),
(7, 1, 'Ngāti Toa Ruatira', 0),
(8, 2, 'Nobel', 1),
(9, 2, 'Chivalrous', 1),
(10, 2, 'Warrior', 0),
(11, 2, 'Honest', 0),
(12, 2, 'Brave', 0),
(13, 3, '1760s', 1),
(14, 3, '1820s', 0),
(15, 3, '1880s', 0),
(16, 3, '1940s', 0),
(17, 4, 'Ka Mate', 1),
(18, 5, 'Death', 1),
(19, 5, 'Die', 1),
(20, 5, 'To Die', 1),
(21, 5, 'Life', 0),
(22, 5, 'Ball', 0),
(23, 5, 'War', 0),
(24, 6, '4', 1),
(25, 6, '1', 0),
(26, 6, '2', 0),
(27, 6, '3', 0),
(28, 7, '2', 1),
(29, 7, '1', 0),
(30, 7, '3', 0),
(31, 7, '4', 0),
(32, 8, 'Waikato', 1),
(33, 8, 'Kawhia', 1),
(34, 8, 'Kāwhia', 1),
(35, 8, 'Auckland', 0),
(36, 8, 'Central Plateau', 0),
(37, 8, 'Manuwatu', 0),
(38, 9, 'Tainui', 1),
(39, 9, 'Tokomaru', 0),
(40, 9, 'Te Arawa', 0),
(41, 9, 'Tākitimu', 0),
(42, 10, 'Ngāti Mahuta', 1),
(43, 10, 'Ngati Mahuta', 1),
(44, 10, 'Ngāti Maniapoto', 0),
(45, 10, 'Ngāti Ira', 0),
(46, 10, ' Ngāti Tara', 0),
(47, 11, 'Tribal boundaries', 1),
(48, 11, 'Basket', 0),
(49, 11, 'Tribal traditions', 0),
(50, 11, 'Electorate', 0),
(51, 12, 'Atiawa Toa FM', 1),
(52, 12, 'Awa FM', 0),
(53, 12, 'Te Arawa FM', 0),
(54, 12, 'Radio Tainui', 0),
(55, 13, '2000', 1),
(56, 13, '2,000', 1),
(57, 13, '2 000', 1),
(58, 13, '600', 0),
(59, 13, '1200', 0),
(60, 13, '2500', 0),
(61, 14, 'Ora Toa', 1),
(62, 14, 'Toa Ora', 0),
(63, 14, 'Hauroa Toa', 0),
(64, 14, 'Toa Hauora', 0),
(65, 15, 'Te Rauparaha', 1),
(66, 15, 'Tupahau', 0),
(67, 15, 'Tamure', 0),
(68, 15, 'Toarangatira', 0),
(69, 16, '1956', 1),
(70, 16, '1962', 0),
(71, 16, '1973', 0),
(72, 16, '1990', 0),
(73, 17, '1970s', 1),
(74, 17, '1960s', 0),
(75, 17, '1980s', 0),
(76, 17, '1990s', 0),
(77, 18, 'Eye', 1),
(78, 18, 'School', 0),
(79, 18, 'Mountain', 0),
(80, 18, 'Lift', 0),
(81, 19, 'Latin', 1),
(82, 19, 'French', 0),
(83, 19, 'Chinese', 0),
(84, 19, 'Greek', 0),
(85, 20, 'Whānau', 1),
(86, 20, 'Whanau', 1),
(87, 20, 'Tangata', 0),
(88, 20, 'Hapu', 0),
(89, 20, 'Iwi', 0),
(90, 21, 'Te Kāreti o Onslow', 1),
(91, 21, 'Te Kura Tuarua o Onslow', 0),
(92, 21, 'Te Kura Kaupapa o Onslow', 0),
(93, 21, 'Te Kura o Onslow', 0),
(94, 22, 'The governor of New Zealand', 1),
(95, 22, 'The college\'s first school principal', 0),
(96, 22, 'Prime Minister of New Zealand', 0),
(97, 22, 'The mayor of Johnsonville', 0),
(98, 23, 'Tarikākā', 1),
(99, 23, 'Tarikaka', 1),
(100, 23, 'Tarikea', 0),
(101, 23, 'Taripukeko', 0),
(102, 23, 'Tarikakapo', 0),
(103, 24, '2013', 1),
(104, 24, '2014', 0),
(105, 24, '2015', 0),
(106, 24, '2016', 0),
(107, 25, '2021', 1),
(108, 25, '2020', 0),
(109, 25, '2019', 0),
(110, 25, '2018', 0),
(111, 26, 'Parrot', 1),
(112, 26, 'Parrots', 1),
(113, 26, 'Bird', 0),
(114, 26, 'Finch', 0),
(115, 26, 'Fantail', 0),
(116, 27, 'Sheena Millar', 1),
(117, 27, 'Miss Millar', 1),
(118, 27, 'Ms Millar', 1),
(119, 27, 'Mrs Millar', 1),
(120, 27, 'Penny Kinsella', 0),
(121, 27, 'Warren Henderson', 0),
(122, 27, 'Janet Glenn', 0),
(123, 28, '5 years', 1),
(124, 28, ' 6 months', 0),
(125, 28, '1 year', 0),
(126, 28, '3 years', 0),
(127, 29, 'Johnsonville', 1),
(128, 29, 'Khandallah', 0),
(129, 29, 'Ngaio', 0),
(130, 29, ' Crofton Downs', 0),
(131, 30, 'The Bible', 1),
(132, 30, 'Bible', 1),
(133, 30, ' A famous poem', 0),
(134, 30, ' The Treaty of Waitangi', 0),
(135, 30, 'A science textbook', 0),
(136, 31, '1841', 1),
(137, 31, '1903', 0),
(138, 31, '1892', 0),
(139, 31, '1884', 0),
(140, 32, '1886', 1),
(141, 32, '1895', 0),
(142, 32, '1904', 0),
(143, 32, '1923', 0),
(144, 33, 'Cowtown', 1),
(145, 33, 'Cowville', 0),
(146, 33, 'Stinkville', 0),
(147, 33, 'Pigland', 0),
(148, 34, 'Wellington', 1),
(149, 34, 'Porirua', 0),
(150, 34, 'Khandallah', 0),
(151, 34, 'Ngaio', 0),
(152, 35, 'Alex Moore Park', 1),
(153, 35, 'Alex Moore', 1),
(154, 35, 'Newlands Skate Park', 0),
(155, 35, 'Johnsonville Park', 0),
(156, 35, 'Totara Park', 0),
(157, 36, 'Johnson', 1),
(158, 36, 'Johnsonville', 0),
(159, 36, 'Johnstone', 0),
(160, 36, 'Jonson', 0),
(161, 37, 'Wellington and Porirua', 1),
(162, 37, 'Wellington and the Hutt Valley', 0),
(163, 37, 'Porirua and the Hutt Valley', 0),
(164, 37, 'Wellington and Karori', 0),
(165, 38, '1958', 1),
(166, 38, '1953', 0),
(167, 38, '1963', 0),
(168, 38, '1968', 0),
(169, 39, 'Waitohi', 1),
(170, 40, 'Electric train line', 1),
(171, 40, 'Flying cars', 0),
(172, 40, 'Subway station', 0),
(173, 40, 'Johnsonville Airport', 0),
(174, 41, '1960s', 1),
(175, 41, '1970s', 0),
(176, 41, '1980s', 0),
(177, 41, '1950s', 0),
(178, 42, 'J\'ville', 1),
(179, 42, 'Jville', 1),
(180, 42, 'J-ville', 1),
(181, 42, 'J Ville', 1),
(182, 42, 'Joville', 0),
(183, 42, 'Johnson', 0),
(184, 42, 'Johnville', 0),
(185, 43, 'Hinau', 1),
(186, 43, 'Hinau tree', 1),
(187, 43, 'Hinau trees', 1),
(188, 43, 'Pine', 0),
(189, 43, 'Oak', 0),
(190, 43, 'Kōwhai', 0),
(191, 44, 'Ngauranga', 1),
(192, 44, 'Manuwatu', 0),
(193, 44, 'Ōtaki River', 0),
(194, 44, 'Waiohine', 0),
(195, 45, '7', 1),
(196, 45, '5', 0),
(197, 45, '10', 0),
(198, 45, '33', 0),
(199, 46, 'England', 1),
(200, 46, 'Scotland', 0),
(201, 46, 'Wales', 0),
(202, 46, 'New Zealand', 0),
(203, 47, 'Harbour', 1),
(204, 47, 'River', 0),
(205, 47, 'Stream', 0),
(206, 47, 'Sea', 0),
(207, 48, 'Māui', 1),
(208, 48, 'Maui', 1),
(209, 48, 'Hina', 0),
(210, 48, 'Makeatutara', 0),
(211, 48, 'Kupe', 0),
(212, 49, 'Pōneke', 1),
(213, 49, 'Port Nick', 1),
(214, 49, 'Poneke', 1),
(215, 49, 'Port Nico', 0),
(216, 49, 'Pōniko', 0),
(217, 49, 'Port Neke', 0),
(218, 50, 'Tory', 1),
(219, 50, 'Taranaki', 0),
(220, 50, 'Cambridge', 0),
(221, 50, 'Aurora', 0),
(222, 51, 'Wakefield', 1),
(223, 51, 'Onslow', 0),
(224, 51, 'Plimmer', 0),
(225, 51, 'Lambton', 0),
(226, 52, 'Pito-one', 1),
(227, 52, 'Pitoone', 1),
(228, 52, 'Petone', 1),
(229, 52, 'Johnsonville', 0),
(230, 52, 'Karori', 0),
(231, 52, 'Eastbourne', 0),
(232, 53, '1840', 1),
(233, 53, '1910', 0),
(234, 53, '2000', 0),
(235, 53, '1880', 0),
(236, 54, '1865', 1),
(237, 54, '1910', 0),
(238, 54, '1880', 0),
(239, 54, '1840', 0),
(240, 55, 'Auckland', 1),
(241, 55, 'Russel', 0),
(242, 55, 'Christchurch', 0),
(243, 55, 'Palmerston North', 0),
(244, 56, '8.2', 1),
(245, 56, '2.4', 0),
(246, 56, '4.8', 0),
(247, 56, '9.0', 0),
(248, 57, 'Lambton Quay is the site of the original harbour before the 1855 earthquake', 1),
(249, 57, 'Lambton Quay was originally a different street', 0),
(250, 57, 'Lambton Quay was originally on a lagoon', 0),
(251, 57, 'Lambton Quay was originally on a swamp', 0),
(252, 58, 'Queen Victoria', 1),
(253, 59, '1902', 1),
(254, 59, '1992', 0),
(255, 59, '1931', 0),
(256, 59, '1950', 0),
(257, 60, 'Prevent the South Island becoming its own separate colony', 1),
(258, 60, 'Make travel times fairer for people coming from the South Island', 0),
(259, 60, 'Get away from Auckland\'s intense humidity', 0),
(260, 60, 'Enjoy flying kites in the Cook Strait winds', 0),
(261, 61, 'Rata', 1),
(262, 61, 'Rata tree', 1),
(263, 61, 'Pōhutukawa', 0),
(264, 61, 'Kauri', 0),
(265, 61, 'Kōwhai', 0),
(266, 62, 'Whānau', 1),
(267, 62, 'Whanau', 1),
(268, 62, 'Whenua', 0),
(269, 62, 'Whakapapa', 0),
(270, 62, 'Community', 0),
(271, 63, '2021', 1),
(272, 63, '2020', 0),
(273, 63, '2019', 0),
(274, 63, '2018', 0),
(275, 64, 'Grow', 1),
(276, 64, 'Growth', 1),
(277, 64, 'Kindness', 0),
(278, 64, 'Pride', 0),
(279, 64, 'Values', 0),
(280, 65, 'Diversity', 1),
(281, 66, 'Whānau', 1),
(282, 66, 'Whanau', 1),
(283, 67, 'Whenua', 1),
(284, 68, 'Whakapapa', 1),
(285, 69, 'Diversity', 1),
(286, 70, 'Community', 1),
(287, 71, 'Kei konei ahau', 1),
(288, 71, 'Kia puāwai', 0),
(289, 71, 'Haere whakamua', 0),
(290, 71, 'All of the above', 0),
(291, 72, 'Kia puāwai', 1),
(292, 72, 'Kei konei ahau', 0),
(293, 72, 'Haera whakamua', 0),
(294, 72, 'All of the above', 0),
(295, 73, 'Haere whakamua', 1),
(296, 73, 'Kei konei ahau', 0),
(297, 73, 'Kia puawai', 0),
(298, 73, 'All of the above', 0),
(299, 74, 'Way', 1),
(300, 74, 'Winds', 0),
(301, 74, 'Wisdom', 0),
(302, 74, 'Wabbit', 0),
(303, 75, 'Akōnga', 1),
(304, 75, 'Rangatahi', 0),
(305, 75, 'Tamariki', 0),
(306, 75, 'Tauira', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Helpful_Info`
--

CREATE TABLE `Helpful_Info` (
  `InfoID` tinyint(3) UNSIGNED NOT NULL,
  `QuizID` tinyint(3) UNSIGNED NOT NULL,
  `InfoLinks` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Storing the links to helpful info for each question';

--
-- Dumping data for table `Helpful_Info`
--

INSERT INTO `Helpful_Info` (`InfoID`, `QuizID`, `InfoLinks`) VALUES
(1, 1, 'info.html#ngati_toa'),
(2, 1, 'https://en.wikipedia.org/wiki/Ng%C4%81ti_Toa'),
(3, 2, 'info.html#onslow_college'),
(4, 2, 'https://en.wikipedia.org/wiki/Onslow_College'),
(5, 3, 'info.html#johnsonville'),
(6, 3, 'https://en.wikipedia.org/wiki/Johnsonville,_New_Zealand'),
(7, 4, 'info.html#wellington'),
(8, 4, 'https://en.wikipedia.org/wiki/Wellington'),
(9, 5, 'info.html#school_values'),
(10, 5, 'https://www.onslow.school.nz/about-us/mission-vision-and-values');

-- --------------------------------------------------------

--
-- Table structure for table `Questions`
--

CREATE TABLE `Questions` (
  `QuestionID` tinyint(3) UNSIGNED NOT NULL,
  `QuizID` tinyint(3) UNSIGNED NOT NULL,
  `Question` varchar(300) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Format` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Storing information about each quiestion by ID';

--
-- Dumping data for table `Questions`
--

INSERT INTO `Questions` (`QuestionID`, `QuizID`, `Question`, `Format`) VALUES
(1, 1, 'What is the full name of the Ngāti Toa iwi?', 'B'),
(2, 1, 'What does ‘rangatira’ stand for?', 'B'),
(3, 1, 'When was Te Rauparaha born?', 'M'),
(4, 1, 'Te Rauparaha is the author of which famous Māori haka, popularly known for being performed by the All Blacks?', 'T'),
(5, 1, 'What does the ‘mate’, from the Ngāti Toa haka penned by Te Rauparaha, stand for?', 'B'),
(6, 1, 'How many marae does Ngāti Toa have?', 'B'),
(7, 1, 'How many marae does Ngāti Toa have on the North Island?', 'B'),
(8, 1, 'Ngāti Toa emigrated southward from which region?', 'B'),
(9, 1, 'Ngāti Toa are descendents of Hoturua, captain of which waka (canoe)?', 'B'),
(10, 1, 'The people of Ngāti Toa who did not migrate south became which tribe?', 'B'),
(11, 1, 'What does \'rohe pōtae\' (in all lower case) mean in English?', 'B'),
(12, 1, 'Alongside the Te Āti Awa iwi, Ngāti Toa operates which radio station in the Wellington region?', 'M'),
(13, 1, 'Tupahau led around 300 warriors against Tamure\'s army of…', 'B'),
(14, 1, 'Today, Ngāti Toa operates health services under the name…', 'B'),
(15, 1, 'Who headed Ngāti Toa\'s migration southward?', 'B'),
(16, 2, 'In what year did Onslow College open?', 'M'),
(17, 2, 'In what decade did Onslow College abolish the school uniform following a student rebellion?', 'M'),
(18, 2, 'In the school’s motto ‘Levavi oculos meos in montes’/‘Ka anga atuaku kanohi ki nga maunga’, what does ‘oculus’/‘kanohi’ mean in English?', 'B'),
(19, 2, 'The school has two versions of its motto ‘Lift your eyes to the hills’. One is in Māori, one is in … what other language?', 'B'),
(20, 2, 'In 2021, Onslow College adopted five new values: whenua, whakapapa, diversity, community … name the missing value:', 'B'),
(21, 2, 'What is the Māori name for Onslow College?', 'B'),
(22, 2, 'For whom is Onslow College named?', 'B'),
(23, 2, 'Onslow College sits beneath what mountain, currently named Mount Kaukau?', 'B'),
(24, 2, 'When was the building now called Te Ara a Maui completed?', 'B'),
(25, 2, 'When did Onslow College implement the new school values?', 'B'),
(26, 2, 'What is \'kākā\' in English?', 'B'),
(27, 2, 'Who is the current principal?', 'B'),
(28, 2, 'Building of the new buildings is expected to take at least…', 'B'),
(29, 2, 'In which suburb is Onslow College located?', 'B'),
(30, 2, 'The school motto is taken from a verse from…', 'B'),
(31, 3, 'In what year was Johnsonville settled?', 'B'),
(32, 3, 'In what year did the railway open in Johnsonville?', 'B'),
(33, 3, 'Due to the stockyards in 1894, where cattle and sheep were rallied, what nickname was given to Johnsonville?', 'B'),
(34, 3, 'In 1953, Johnsonville amalgamated with the council of which area?', 'B'),
(35, 3, 'On the corner of Moorefield and Broderick Roads lies what sports park, due for redevelopment with a $6 million sports centre?', 'B'),
(36, 3, 'Johnsonville was named for the early settler Frank…', 'B'),
(37, 3, 'Originally, the site where Johnsonville is was originally a track between…', 'M'),
(38, 3, 'The cowtown stockyards were relocated to Raroa Station in what year?', 'B'),
(39, 3, 'What is the name of the hub where Johnsonville\'s new public library is?', 'T'),
(40, 3, 'What technology, introduced in 1938, allowed more commuters from Johnsonville\'s newly-built state houses to Wellington city?', 'M'),
(41, 3, 'The first shopping mall in the Wellington region was built in what decade?', 'M'),
(42, 3, 'What is the common shortened name for Johnsonville?', 'B'),
(43, 3, 'The dense native forest in the Johnsonville area included Totara, Rata, Rimu, and…', 'B'),
(44, 3, 'What gorge separates Johnsonville from Wellington?', 'B'),
(45, 3, 'How many kilometres from Wellington City does Johnsonville lie?', 'B'),
(46, 4, 'Onslow College is named for the 4th Earl of Onslow, born in what country?', 'B'),
(47, 4, 'In the Māori name for Wellington, Te Whanganui-a-Tara, what does ‘whanganui’ mean?', 'B'),
(48, 4, 'Matiu (Somes Island) and Mākaro (Ward Island) are named after the daughters of which legendary figure in Māori mythology?', 'B'),
(49, 4, 'The former name for Wellington, Port Nicholson, is often shortened to:', 'B'),
(50, 4, 'European settlement in Wellington began in the 1920s, starting with an advance party from the ship:', 'B'),
(51, 4, 'What is the surname of the colonel who came from Britain to New Zealand in 1839 to purchase land?', 'B'),
(52, 4, 'The first homes built by European settlers were constructed in…', 'B'),
(53, 4, 'In what year was Wellington declared a city?', 'B'),
(54, 4, 'In what year was Wellington declared New Zealand\'s capital city?', 'B'),
(55, 4, 'What was the capital city before Wellington?', 'B'),
(56, 4, 'Likely the most powerful earthquake in recorded New Zealand history, the 1855 Wairarapa earthquake that raised the land in the area by 2 to 3 metres reached what magnitude on the Moment scale?', 'M'),
(57, 4, 'Why is Lambton Quay around 100 to 200 metres from Wellington Harbour?', 'M'),
(58, 4, 'For whom was Victoria University originally named?', 'B'),
(59, 4, 'When did the Wellington Cable Car begin service?', 'B'),
(60, 4, 'Wellington was chosen as the capital city in order to…', 'M'),
(61, 5, 'When adopting the new school vision and values, what type of tree was selected as the emblem to represent them?', 'B'),
(62, 5, 'Which value stands for the following? “We work hard to make sure that everyone feels safe”.', 'B'),
(63, 5, 'In what year were the new school values adopted?', 'B'),
(64, 5, 'For the line ‘kia puāwai’ from the school vision, what word best translates the meaning into English?', 'M'),
(65, 5, 'Name the missing value: whanau, whenua, whakapapa, community.', 'T'),
(66, 5, 'Name the value: \'this value is about Onslow College being an extended family, a collective who care. We take the time to know each other, and we work hard to make sure that everyone feels safe\'.', 'T'),
(67, 5, 'Name the value: \'this value is about Onslow College being a place for akōnga to find sustenance so that they can grow and strive. This means we focus on wellbeing and identity in all that we do and say to sustain growth and the ability to thrive\'.', 'T'),
(68, 5, 'Name the value: \'this value is about the layers which make up who we are. The way these layers combine make us unique. It also identifies all that akōnga bring with them each day. The way our families and influences make us who we are and how they connect us\'.\r\n', 'T'),
(69, 5, 'Name the value: \'this value is about including and accepting people of different social, socio-economic, learning styles, ethnic, genders, faith, sexual orientation…\'.', 'T'),
(70, 5, 'Name the value: \'this value highlights that Onslow College is a group of people that care about each other and feel they belong together. A group of people who balance the rights of the individual against what is best for the group\'.', 'T'),
(71, 5, 'Which of these vision statements means \'You bring yourself\'?', 'M'),
(72, 5, 'Which of these vision statements means \'Grow\'?', 'M'),
(73, 5, 'Which of these vision statements means \'Thrive in the paths you choose\'?', 'M'),
(74, 5, 'The school vision is also called The Onslow W…', 'B'),
(75, 5, 'What is the Māori term for \'learner\'?', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `Quizzes`
--

CREATE TABLE `Quizzes` (
  `QuizID` tinyint(3) UNSIGNED NOT NULL,
  `QuizName` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Storing name of quiz under ID''s';

--
-- Dumping data for table `Quizzes`
--

INSERT INTO `Quizzes` (`QuizID`, `QuizName`) VALUES
(1, 'Ngati Toa'),
(2, 'Onslow College'),
(3, 'Johnsonville'),
(4, 'Wellington'),
(5, 'School Values');

-- --------------------------------------------------------

--
-- Table structure for table `Results`
--

CREATE TABLE `Results` (
  `ResultID` tinyint(3) UNSIGNED NOT NULL,
  `QuizID` tinyint(3) UNSIGNED NOT NULL,
  `Name` char(10) NOT NULL,
  `Score` smallint(4) UNSIGNED ZEROFILL NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Storing results for each quiz and name user inputs, but only displaying the top 10';

--
-- Dumping data for table `Results`
--

INSERT INTO `Results` (`ResultID`, `QuizID`, `Name`, `Score`) VALUES
(1, 1, 'NON', 0000),
(2, 1, 'NON', 0000),
(3, 1, 'NON', 0000),
(4, 1, 'NON', 0000),
(5, 1, 'NON', 0000),
(6, 1, 'NON', 0000),
(7, 1, 'NON', 0000),
(8, 1, 'NON', 0000),
(9, 1, 'NON', 0000),
(10, 1, 'NON', 0000),
(23, 2, 'Benjy', 0001),
(25, 3, '* Chara.', 0400),
(27, 2, 'Alan', 0800),
(29, 4, 'Ryan', 0700),
(30, 2, 'Doc', 0800);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Answers`
--
ALTER TABLE `Answers`
  ADD PRIMARY KEY (`AnswerID`),
  ADD KEY `QuestionID` (`QuestionID`);

--
-- Indexes for table `Helpful_Info`
--
ALTER TABLE `Helpful_Info`
  ADD PRIMARY KEY (`InfoID`),
  ADD KEY `Helpful Info_ibfk_1` (`QuizID`);

--
-- Indexes for table `Questions`
--
ALTER TABLE `Questions`
  ADD PRIMARY KEY (`QuestionID`),
  ADD KEY `QuizID` (`QuizID`);

--
-- Indexes for table `Quizzes`
--
ALTER TABLE `Quizzes`
  ADD PRIMARY KEY (`QuizID`);

--
-- Indexes for table `Results`
--
ALTER TABLE `Results`
  ADD PRIMARY KEY (`ResultID`),
  ADD KEY `QuizID` (`QuizID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Answers`
--
ALTER TABLE `Answers`
  MODIFY `AnswerID` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307;

--
-- AUTO_INCREMENT for table `Helpful_Info`
--
ALTER TABLE `Helpful_Info`
  MODIFY `InfoID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Questions`
--
ALTER TABLE `Questions`
  MODIFY `QuestionID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `Quizzes`
--
ALTER TABLE `Quizzes`
  MODIFY `QuizID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `Results`
--
ALTER TABLE `Results`
  MODIFY `ResultID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Answers`
--
ALTER TABLE `Answers`
  ADD CONSTRAINT `Answers_ibfk_1` FOREIGN KEY (`QuestionID`) REFERENCES `Questions` (`QuestionID`);

--
-- Constraints for table `Helpful_Info`
--
ALTER TABLE `Helpful_Info`
  ADD CONSTRAINT `Helpful_Info_ibfk_1` FOREIGN KEY (`QuizID`) REFERENCES `Quizzes` (`QuizID`);

--
-- Constraints for table `Questions`
--
ALTER TABLE `Questions`
  ADD CONSTRAINT `Questions_ibfk_1` FOREIGN KEY (`QuizID`) REFERENCES `Quizzes` (`QuizID`);

--
-- Constraints for table `Results`
--
ALTER TABLE `Results`
  ADD CONSTRAINT `Results_ibfk_1` FOREIGN KEY (`QuizID`) REFERENCES `Quizzes` (`QuizID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
