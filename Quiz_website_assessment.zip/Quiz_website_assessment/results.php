<?php
$id = intval($_GET['id']);
$dbc = mysqli_connect("localhost", "thompsal", '$2y$10$YuhE1dWv3xY4J5aOdllJF.Arr8WH8Z8dYAoInl6ZtmGOrIHuHBhde', "thompsal_Quiz_questions_and_answers");
$query = "SELECT InfoLinks FROM Helpful_Info WHERE QuizID = $id";
$helpfulLinks = [];
$result = mysqli_query($dbc, $query);
while ($tmp = mysqli_fetch_assoc($result)) {
	array_push($helpfulLinks, $tmp["InfoLinks"]);
};
$helpfulLinks = addslashes(json_encode($helpfulLinks));
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<!-- This is the icon that appears in the tab at the top of the browser -->
	<link rel="shortcut icon" href="Images/favicon.ico" type="image/x-icon">
	<title>Results</title>
	<meta name="description" content=" ... ">
	<link href="CSS/results.css" rel="stylesheet">
	<link href="CSS/scrollbar.css" rel="stylesheet">
	<script src="https://kit.fontawesome.com/c234132872.js" crossorigin="anonymous"></script>
	<script src="JS/script.js"></script>
</head>

<body onload='calc_result("<?php echo $helpfulLinks; ?>")'>
	<header>
		<h2>Your score is...</h2>
		<div class="break"></div>
		<img src="Images/dog.jpg">
		<div id="result">
			<h1></h1>
			<div class="break"></div>
			<h3></h3>
		</div>
		<img src="Images/dog.jpg" style="transform: scaleX(-1);">
	</header>
	<main>
		<button onclick="expand_results()">More info</button>
		<div class="break"></div>
		<div id="answers">
		</div>
	</main>
	<footer>
		<a href="index.html" class="option">
			<h2>Back to quiz selection.</h2>
			<div class="underline"></div>
			<i class="fas fa-chevron-circle-left icon"></i>
		</a>
		<a href="quiz.php?id=<?php echo $_GET['id'] ?>" class="option" style="width: 9vw">
			<h2>Again?</h2>
			<div class="underline"></div>
			<i class="fas fa-sync-alt icon"></i>
		</a>
		<a onclick="get_name()" href="insert_result.php?id=<?php echo $_GET['id'] ?>" class="option">
			<h2>Log your results.</h2>
			<div class="underline"></div>
			<i class="fas fa-check-circle icon"></i>
		</a>
	</footer>
</body>