<?php

$dbc = mysqli_connect("localhost", "thompsal", '$2y$10$YuhE1dWv3xY4J5aOdllJF.Arr8WH8Z8dYAoInl6ZtmGOrIHuHBhde', "thompsal_Quiz_questions_and_answers");
mysqli_set_charset($dbc, "utf8");
if (mysqli_connect_errno()) {
	echo "<p>Connection error: " . mysqli_connect_error() . "</p>";
	exit();
}

$id = intval($_GET['id']);
$query = "SELECT Questions.QuestionID, Questions.Question, Questions.Format, Answers.Answer, Answers.Correct FROM Questions JOIN Answers ON Answers.QuestionID=Questions.QuestionID WHERE QuizID = $id";

$result = mysqli_query($dbc, $query);

// Turn query results into workable 2d array format

$allQuestions = [];
$current_question = NULL;
$question_info = [];
$correct = [];
$wrong = [];
while($message = $result->fetch_assoc()) {

	if ($current_question != $message["QuestionID"]) {
		// If this is a new question, then add the previous questions data to $allQuestions and create the new data, this will create a blank first array in $allQuestions, but that will be deleted later
// 		array_push($question_info, $correct, $wrong);
		$question_info["Correct"] = $correct;
		$question_info["Wrong"] = $wrong;
		array_push($allQuestions, $question_info);
		$question_info = [];
		$correct = [];
		$wrong = [];
		$question_info["Question"] = $message["Question"];
		$question_info["Format"] = $message["Format"];
	}
	
	if ($message["Correct"] == "1") {
		array_push($correct, $message["Answer"]);
	} else {
		array_push($wrong, $message["Answer"]);
	}
	
	$current_question = $message["QuestionID"];
}

unset($allQuestions[0]);

shuffle($allQuestions);
$sessionQuestions = array_slice($allQuestions, 0, 10);