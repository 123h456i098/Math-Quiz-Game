<?php
function nameQuiz() {
	//Simply grabbing the name of the quiz from the database to display on the tab title
	$id = intval($_GET['id']);
	$dbc = mysqli_connect("localhost", "thompsal", '$2y$10$YuhE1dWv3xY4J5aOdllJF.Arr8WH8Z8dYAoInl6ZtmGOrIHuHBhde', "thompsal_Quiz_questions_and_answers");
	$query = "SELECT QuizName FROM Quizzes WHERE QuizID = $id";
	print_r(mysqli_fetch_assoc(mysqli_query($dbc, $query))["QuizName"]);
}

function loadQuiz() {
    /**
     * Loads the quiz. If one is in progress, it continues that quiz.
     * Otherwise, it loads a new one.
     */

    // Loading in shuffled session questions from a PHP dictionary.
    

    // Check if the 'asked' GET variable has been declared. If so, then a quiz is in progress and we should continue it.
    // If not, then start a new quiz.
    if (!isset($_GET['asked'])) {
		// Start a new quiz.
		include('questions.php');
		$jsonSessionQuestions = json_encode($sessionQuestions);
		setcookie("cookieSessionQuestions", $jsonSessionQuestions, time() + (86400 * 1), "/"); //86400 = 1 day, (in secs)
        loadNextQuestion($sessionQuestions, 0);
		
    } else {
		$jsonSessionQuestions = $_COOKIE["cookieSessionQuestions"];
		$sessionQuestions = json_decode($jsonSessionQuestions, true);
		
        $numberAsked = intval($_GET['asked']) + 1;
		$sessionQuestions = array_slice($sessionQuestions, $numberAsked);
		
        loadNextQuestion($sessionQuestions, $numberAsked);
    }
}

function loadNextQuestion($questions, $numberAsked) {
    switch ($numberAsked == 10) {
        case true:
            createResultsHTML();
            break;
		default:
			// If to generate either multichoice or text question
			if ($questions[0]["Format"] == "B") {
				if (rand(1, 2) == 1) {
					createQuestionMultiHTML($questions[0], $numberAsked);
				} else {
					createQuestionTextHTML($questions[0], $numberAsked);
				}
			} elseif ($questions[0]["Format"] == "M") {
				createQuestionMultiHTML($questions[0], $numberAsked);
			} else {
				createQuestionTextHTML($questions[0], $numberAsked);
			}
            break;
    }
}

function createQuestionMultiHTML($currentQuestion, $numberAsked) {
    /**
     * Loads in information about the current question, its answers,
     * and formats them nicely on the page.
     */
    $questionText = $currentQuestion["Question"];
//     $answer = str_replace("'","\'", $currentQuestion["Correct"][0]);
    $answer = $currentQuestion["Correct"][0];
    $wrongAnswers = $currentQuestion["Wrong"];
    $allAnswers = array_merge([$answer], $wrongAnswers);
// 	for ($i = 0; $i < 3; $i++) {
// 		$allAnswers[$i] = str_replace("'","/'", $allAnswers[$i]);
// 	}
    shuffle($allAnswers);

    // Put all the question/answer information into the template for multichoice question
    echo "<div class='break'></div>
	<h1> $questionText </h1>
	<div class='break'></div>
	<div id='options'>";

    foreach (range(0, count($allAnswers) - 1) as $index) {
        $currentAnswer = $allAnswers[$index];
		$addSlashAnswer = addslashes($currentAnswer);
		
		?>
		<button class='option' onclick="users_answers.select('<?php echo $addSlashAnswer; ?>', <?php echo $index; ?>)"> <?php echo $currentAnswer; ?> </button>
		<?php
    }
	$id = $_GET["id"];
	$dont_know = "Don't Know?";

    echo "</div>";
	// out of PHP ?>

	<script>
		var input = document.getElementById("options");
		var origin = new Date()
		input.addEventListener("keydown", function(event) {
			var current_date = new Date()
			if (event.keyCode == 13 && (origin.getTime() + 250) <= current_date.getTime()) {
				document.getElementById("check").click();
			}
		});
	</script>

	<?php // back to PHP
	echo "<div class='break'></div>";
// 	need to do the java script for this and fix text input as well
	echo "<div class='next-question'>
        <button id='dont_know' onclick='users_answers.confirm(1, $numberAsked, $id)'>Don't Know</button>
        <button id='check' onclick='users_answers.confirm(0, $numberAsked, $id)'>Check</button>
    </div>";
};

function createQuestionTextHTML($currentQuestion, $numberAsked) {
    $questionText = $currentQuestion["Question"];
    $answers = $currentQuestion["Correct"];
    $json_answers = htmlspecialchars(json_encode($answers), ENT_QUOTES);
    $dont_know = "Don't Know?";
    $id = $_GET["id"];
    
    echo "<div class='break'></div>
    <h1 id='text_question'> $questionText </h1>
    <div class='break'></div>
    <input id='text_input' maxlength='50' type='text' placeholder='Type your answer here' autofocus>
    <div class='break'></div>";
    $questionText = addslashes($questionText);
    // out of PHP ?>

	<script>
		var input = document.getElementById("text_input");
		var origin = new Date()
		input.addEventListener("keydown", function(event) {
			var current_date = new Date()
			if (event.keyCode == 13 && (origin.getTime() + 250) <= current_date.getTime()) {
				document.getElementById("check").click();
			}
		});
	</script>

	<?php // back to PHP
	echo "<div class='next-question'>
        <button id='dont_know' onclick='users_answers.text_input(1, $numberAsked, $id)'>Don't Know</button>
        <button id='check' onclick='users_answers.text_input(0, $numberAsked, $id)'>Check</button>
    </div>";
    
};

function createResultsHTML() {
	$id = $_GET["id"];
    header( "Location: results.php?id=$id" );
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
	<!-- This is the icon that appears in the tab at the top of the browser -->
	<link rel="shortcut icon" href="Images/favicon.ico" type="image/x-icon">
	<title>Quiz - <?php nameQuiz(); ?></title>
	<meta name="description" content=" ... ">
	<link href="CSS/questions.css" rel="stylesheet">
	<link href="CSS/scrollbar.css" rel="stylesheet">
	<script src="https://kit.fontawesome.com/c234132872.js" crossorigin="anonymous"></script>
	<script src="JS/script.js"></script>
</head>

<body onload="progressBar()">
	<div id="progress_bar">
		<div class="question"></div>
		<div class="question"></div>
		<div class="question"></div>
		<div class="question"></div>
		<div class="question"></div>
		<div class="question"></div>
		<div class="question"></div>
		<div class="question"></div>
		<div class="question"></div>
		<div class="question"></div>
	</div>
	<div class="break"></div>
	<a id="back" href="index.html">
		<i class="fas fa-chevron-left" id="back_arrow"></i>
	</a>
    <?php loadQuiz(); ?>
</body>

</html>