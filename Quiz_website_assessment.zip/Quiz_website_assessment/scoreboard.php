<?php
$dbc = mysqli_connect("localhost", "thompsal", '$2y$10$YuhE1dWv3xY4J5aOdllJF.Arr8WH8Z8dYAoInl6ZtmGOrIHuHBhde', "thompsal_Quiz_questions_and_answers");
mysqli_set_charset($dbc, "utf8");
if (mysqli_connect_errno()) {
	echo "<p>Connection error: " . mysqli_connect_error() . "</p>";
	exit();
}
	
$query = "SELECT * FROM `Results` ORDER BY `Results`.`Score` DESC LIMIT 10";
$result = mysqli_query($dbc, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<!-- This is the icon that appears in the tab at the top of the browser -->
	<link rel="shortcut icon" href="Images/favicon.ico" type="image/x-icon">
	<title>Home-Scoreboard</title>
	<meta name="description" content=" ... ">
	<link href="CSS/style.css" rel="stylesheet">
	<link href="CSS/scrollbar.css" rel="stylesheet">
</head>
<body>
	<header>
		<a href="index.html"><img src="Images/onslow_logo.png" alt="The onslow logo, which links to the home page" title="Help Logo - Link to home page"></a>
		<nav>
			<ul>
				<li><a href="info.html">Learn</a></li>
				<li><a href="index.html">Quizzes</a></li>
				<li><a href="scoreboard.php" id="current">Results</a></li>
			</ul>
		</nav>
	</header>
	<main id="highscores">
		<h1>Highscores</h1>
		<table>
			<tr>
				<th style="width: 20vw">Quiz Number</th>
				<th style="width: 50vw">Name</th>
				<th style="width: 20vw">Score</th>
			</tr>
			
			<?php
				while ($record = mysqli_fetch_assoc($result)) {		
					echo "<tr>"; // New row per record

					echo "<td id='quiz_number'>" . $record['QuizID'] . "</td>";

					echo "<td id='user_name'>" . $record['Name'] . "</td>";

					echo "<td id='score'>" . $record['Score'] . "</td>";

					echo "</tr>"; // Close the row for this record
				}
			?>
		</table>
	</main>
</body>
</html>