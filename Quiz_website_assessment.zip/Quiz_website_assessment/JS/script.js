const users_answers = {
	All_answers: [],
	current_answer: "No answer given",
	current_box: 0,
	text_correct: false,
	
	// Function to keep changing the users answer as they select different boxes
	select: function(answer, box) {
		this.current_answer = answer;
		this.current_box = box;
	},
	
	decode_cookie: function() {
		// turns cookie of questions into an array again
		let cookie = decodeURIComponent(document.cookie.slice(document.cookie["indexOf"]("cookieSessionQuestions")+23));
		let questions = JSON.parse(cookie);
		return questions;
	},
	
	generate: function (numberAsked, quizID) {
		//preparing everything that doesn't depend on if the user got the answer right or not
		if (numberAsked == 0) {
// 			if this is the first time this is happening for the quiz, put All_answers into local storage
			for (i=0; i<10; i++) {
  				this.All_answers.push(["PlaceHolder", "PlaceHolder"])
			}
			localStorage.setItem("All_answers", JSON.stringify(this.All_answers));
		}
		var icon = document.createElement("i");
		var answer_info = document.createElement("p");
		var answer_status = document.createElement("h1");
		var link = document.createElement("a");
		var procceed = document.createElement("button");
		icon.id = "icon";
		answer_info.id = "answer_info";
		answer_status.id = "answer_status";
		link.id = "continue_link";
		procceed.id = "continue_button";
		procceed.innerHTML = "Continue";
		link.href = "quiz.php?id=" + quizID + "&asked=" + numberAsked;
		return {icon, answer_info, answer_status, link, procceed};
	},
	
	correct: function (icon, answer_status, numberAsked) {
// 		get All_answers from local storage, update it, then put it back
		this.All_answers = JSON.parse(localStorage.getItem("All_answers"));
		this.All_answers[numberAsked] = ["Correct", this.current_answer];
		
		localStorage.setItem("All_answers", JSON.stringify(this.All_answers));
		
// 		setting icon, header text and class names for a correct answer box
		document.getElementsByClassName("next-question")[0].style.backgroundColor = "#aedd94";
		icon.className = "fas fa-check";
		answer_status.innerHTML = "Correct!";
		this.new_progress("Correct");
		return {icon, answer_status};
	},
	
	wrong: function (icon, answer_status, numberAsked) {
		this.All_answers = JSON.parse(localStorage.getItem("All_answers"));
		if (this.current_answer == "") {
			this.current_answer = "No answer given";
		}
		this.All_answers[numberAsked] = ["Wrong", this.current_answer];
		localStorage.setItem("All_answers", JSON.stringify(this.All_answers));
		
// 		setting icon, header text and class names for a correct answer box
		document.getElementsByClassName("next-question")[0].style.backgroundColor = "#ff8a84";
		icon.className = "fas fa-times";
		answer_status.innerHTML = "Sorry.";
		this.new_progress("Wrong");
		return {icon, answer_status};
	},
	
	dontknow: function (icon, answer_status, numberAsked) {
		this.All_answers = JSON.parse(localStorage.getItem("All_answers"));
		this.All_answers[numberAsked] = ["Don't Know", "No answer given"];
		localStorage.setItem("All_answers", JSON.stringify(this.All_answers));
		
// 		setting icon, header text and class names for a correct answer box
		document.getElementsByClassName("next-question")[0].style.backgroundColor = "#75a9f9";
		icon.className = "fas fa-question";
		answer_status.innerHTML = "The answer is";
		this.new_progress("Don't Know");
		return {icon, answer_status};
	},
	
	display: function (icon, answer_status, answer_info, link, procceed) {
		var br = document.createElement("div");
		br.className = "break";
		var answer_box = document.createElement("div");
		answer_box.id = "answer_text";
		//removing previous html and adding new
		var next_question = document.getElementsByClassName("next-question")[0];

		let enter_area = document.getElementsByTagName("body")[0];
		var origin = new Date()
		// Execute a function when the user releases a key on the keyboard
		enter_area.addEventListener("keydown", function(event) {
			// Number 13 is the "Enter" key on the keyboard
			var current_date = new Date()
			if (event.keyCode == 13 && (origin.getTime() + 250) <= current_date.getTime()) {
				// Trigger the button element with a click
				document.getElementById("continue_link").click()
			}
		});
		
		
		next_question.children[1].remove();
		next_question.children[0].remove();
		next_question.style.borderStyle = "Solid";
		next_question.appendChild(icon);
		answer_box.appendChild(answer_status);
		answer_box.appendChild(br);
		answer_box.appendChild(answer_info);
		next_question.appendChild(answer_box);
		link.appendChild(procceed);
		next_question.appendChild(link);
		// some extra css
		next_question.style.width = "70vw";
		next_question.style.padding = "0";
	},
	
	confirm: function(dont_know, numberAsked, quizID) {
		var {icon, answer_info, answer_status, link, procceed} = this.generate(numberAsked, quizID);
		
		let correct = this.decode_cookie()[numberAsked]["Correct"][0];
		answer_info.innerHTML = "The correct answer was " + correct + ".";
		
// 		depending on if they got the question right, wrong, or dont know use corresponding functions to style and add html
		if (dont_know == 1) {
			var {icon, answer_status} = this.dontknow(icon, answer_status, numberAsked);
		} else if (this.current_answer == correct) {
			var {icon, answer_status} = this.correct(icon, answer_status, numberAsked);
			document.getElementsByClassName("option")[this.current_box].style.backgroundColor = "#aedd94";
			document.getElementsByClassName("option")[this.current_box].style.borderColor = "#72bb53";
		} else {
			var {icon, answer_status} = this.wrong(icon, answer_status, numberAsked);
			document.getElementsByClassName("option")[this.current_box].style.backgroundColor = "#ff8a84";
			document.getElementsByClassName("option")[this.current_box].style.borderColor = "#ff3823";
		}
// 		finally display eveything
		this.display(icon, answer_status, answer_info, link, procceed);
		document.getElementsByClassName("option")[this.current_box].style.opacity = "1";
	},
	
	text_input: function(dont_know, numberAsked, quizID) {
		var {icon, answer_info, answer_status, link, procceed} = this.generate(numberAsked, quizID);
		
		let answers = this.decode_cookie()[numberAsked]["Correct"];
		answer_info.innerHTML = "The correct answer was " + answers[0] + ".";
		
		this.current_answer = document.getElementById("text_input").value.toLowerCase().trim();
		if (this.current_answer != "") {
			
			for (let i = 0; i < answers.length; i++) {
				if (this.current_answer == answers[i].toLowerCase().trim()) {
					this.text_correct = true;
					break;
				}
			}
			if (dont_know == 1) {
				var {icon, answer_status} = this.dontknow(icon, answer_status, numberAsked);
			} else if (this.text_correct) {
				var {icon, answer_status} = this.correct(icon, answer_status, numberAsked);
				document.getElementById("text_input").style.backgroundColor = "#aedd94";
			} else {
				var {icon, answer_status} = this.wrong(icon, answer_status, numberAsked);
				document.getElementById("text_input").style.backgroundColor = "#ff8a84";
			}
		} else {
			if (dont_know == 1) {
				var {icon, answer_status} = this.dontknow(icon, answer_status, numberAsked);
			} else {
				var {icon, answer_status} = this.wrong(icon, answer_status, numberAsked);
				document.getElementById("text_input").style.backgroundColor = "#ff8a84";
			}
		}
		
		this.display(icon, answer_status, answer_info, link, procceed);
	},
	
	new_progress: function(status) {
		let answers = JSON.parse(localStorage.getItem("All_answers"));
		var num_answers = 0;
		for (i=0; i<answers.length; i++) {
			if (answers[i][0] != "PlaceHolder") {
				num_answers++;
			}
		}
		let bar = document.getElementById("progress_bar").children;
		if (status == "Correct") {
			bar[num_answers-1].style.backgroundColor = "#aedd94";
		} else if (status == "Wrong") {
			bar[num_answers-1].style.backgroundColor = "#ff8a84";
		} else {
			bar[num_answers-1].style.backgroundColor = "#75a9f9";
		}
	}
}

function progressBar() {
	var answers = JSON.parse(localStorage.getItem("All_answers"));
	let str = window.location.href;
	if (str.charAt(str.indexOf("&asked=")+7) == "/") {
		answers = [];
		localStorage.setItem("All_answers", JSON.stringify(answers));
	}
	
	let bar = document.getElementById("progress_bar").children;
	for (let i = 0; i < answers.length; i++) {
		if (answers[i][0] == "Correct") {
			bar[i].style.backgroundColor = "#aedd94";
		} else if (answers[i][0] == "Wrong") {
			bar[i].style.backgroundColor = "#ff8a84";
		} else if (answers[i][0] == "Don't Know") {
			bar[i].style.backgroundColor = "#75a9f9";
		}
	}
	var num_answers = 0;
		for (i=0; i<answers.length; i++) {
			if (answers[i][0] != "PlaceHolder") {
				num_answers++;
			}
		}
	bar[num_answers].style.opacity = 1;
	bar[num_answers].style.filter = "drop-shadow(3px 3px 1px #072547)";
}

function create_result_boxes(helpful_links) {
	let links = JSON.parse(helpful_links);
	let answers = JSON.parse(localStorage.getItem("All_answers"));
	let questions = users_answers.decode_cookie();
	
	let all_answer_box = document.getElementById("answers")
	
	for (let i = 0; i < 10; i++) {
		if (answers[i][0] != "Correct") {
			
// 			<div class="question">
// 				<h1>Question text</h1>
// 			</div>
			
			var h_1 = document.createElement("h1");
			h_1.innerHTML = questions[i]["Question"];
			var question_box = document.createElement("div");
			question_box.className = "question";
			question_box.appendChild(h_1);

// 			<div class="their_answer">
// 				<h2>Your Answer</h2>
// 				<p>Their answer</p>
// 			</div>
			
			var h_2 = document.createElement("h2");
			h_2.innerHTML = "Your Answer";
			var their_answer = document.createElement("p");
			their_answer.innerHTML = answers[i][1];
			var their_answer_box = document.createElement("div");
			their_answer_box.className = "their_answer";
			their_answer_box.appendChild(h_2);
			their_answer_box.appendChild(their_answer);
			
// 			<div class="answer">
// 				<h2>Correct Answer</h2>
// 				<p>Correct answer</p>
// 			</div>
			
			var h_3 = document.createElement("h2");
			h_3.innerHTML = "Correct Answer";
			var correct_answer = document.createElement("p");
			correct_answer.innerHTML = questions[i]["Correct"][0];
			var correct_answer_box = document.createElement("div");
			correct_answer_box.className = "answer";
			correct_answer_box.appendChild(h_3);
			correct_answer_box.appendChild(correct_answer);
			
// 			<div class="other_info">
// 				<h2>Helpful Info</h2>
// 				<ul>
// 					<li><a href="info.html">link to helpful information</a></li>
// 					<li><a href="info.html">another link to information</a></li>
// 				</ul>
// 			</div>
			
			var h_4 = document.createElement("h2");
			h_4.innerHTML = "Helpful Info";
			var a_1 = document.createElement("a");
			a_1.href = links[0];
			a_1.innerHTML = links[0];
			a_1.target = "_blank";
			var a_2 = document.createElement("a");
			a_2.href = links[1];
			a_2.innerHTML = links[1];
			a_2.target = "_blank";
			var li_1 = document.createElement("li");
			li_1.appendChild(a_1);
			var li_2 = document.createElement("li");
			li_2.appendChild(a_2);
			var ul = document.createElement("ul");
			ul.appendChild(li_1);
			ul.appendChild(li_2);
			var helpful_info_box = document.createElement("div");
			helpful_info_box.className = "other_info";
			helpful_info_box.appendChild(h_4);
			helpful_info_box.appendChild(ul);

// 			<div class="answer_box">
// 				<div class="question"> </div>
// 				<div class="their_answer"> </div>
// 				<div class="answer"> </div>
// 				<div class="other_info"> </div>
// 			</div>
			
			var answer_box = document.createElement("div");
			answer_box.className = "answer_box";
			answer_box.appendChild(question_box);
			answer_box.appendChild(their_answer_box);
			answer_box.appendChild(correct_answer_box);
			answer_box.appendChild(helpful_info_box);
			
			let line = document.createElement("div");
			line.className = "line";
			
			all_answer_box.appendChild(answer_box);
			all_answer_box.appendChild(line);
		}
	}
	
	all_answer_box.removeChild(all_answer_box.lastChild); 
}



function calc_result(helpful_links) {
	let answers = JSON.parse(localStorage.getItem("All_answers"));
	var correct = 0;
	for (let i = 0; i < answers.length; i++) {
		if (answers[i][0] == "Correct") {
			correct++;
		}
	}
	var score = correct.toString();
	document.cookie = "score="+score+"00";
	document.getElementById("result").children[0].innerHTML = correct*10 + "%";
	document.getElementById("result").children[2].innerHTML = correct + "/10";
	create_result_boxes(helpful_links);
}

function get_name() {
	do {
		 var name = prompt('What name would you like on the leader board?\nMax 10 charaters', 'Type here');
	}
	while (name == "null" || name == "");
	document.cookie = "name="+name;
}

function expand_results() {
	document.getElementById("answers").style.maxHeight = "500vh"
}